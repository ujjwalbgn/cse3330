CREATE VIEW [vRentalInfo] AS
SELECT rental.OrderDate, rental.StartDate, rental.ReturnDate,(Julianday(ReturnDate)-Julianday(StartDate)) AS 'TotalDays', vehicle.VehicleID AS 'VIN', vehicle.Description AS 'Vehicle',
	CASE WHEN vehicle.Type = 1 THEN 'Compact'
		WHEN vehicle.Type = 2 THEN 'Medium'
		WHEN vehicle.Type = 3 THEN 'Large'
		WHEN vehicle.Type = 4 THEN 'SUV'
		WHEN vehicle.Type = 5 THEN 'Truck'
		WHEN vehicle.Type = 6 THEN 'Van'
	END	As "Vehicle Type",
	CASE WHEN vehicle.Category = 0 THEN 'Basic'
		WHEN vehicle.Category = 1 THEN 'Luxury'
	END	As 'Category',
	customer.CustID AS 'CustomerID',
	customer.name AS 'CustomerName',
	rental.TotalAmount AS  'OrderAmount',
	CASE WHEN rental.PaymentDate != 'NULL'  THEN rental.TotalAmount
		ELSE 0
	END AS RentalBalance
FROM vehicle
INNER JOIN customer, rental, rate
ON customer.CustID = rental.CustID AND rental.VehicleID = vehicle.VehicleID AND vehicle.Type = rate.Type AND vehicle.Category = rate.Category;

